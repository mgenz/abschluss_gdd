// Map_gdp View
var view = new ol.View({
    center: ol.proj.fromLonLat([13, 52]),
    zoom: 4,
});

//gdp WMS-Layer
var gdplayer = new ol.layer.Tile({
    // Countries have transparency, so do not fade tiles:
    opacity: 1,
    visible: true,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8585/geoserver/abschluss_gdd/wms?',
        params: { 'LAYERS': 'abschluss_gdd:gdp', 'TILED': true, 'Version': '1.1.0' },
        serverType: 'geoserver',
        crossOrigin: null,
        // Countries have transparency, so do not fade tiles:
        transition: 0.5
    })
});

//gdp WFS-Layer
var gdp_style = new ol.style.Style({
    stroke: new ol.style.Stroke({
        color: 'rgba(0, 0, 0)',
        width: 1,
    }),
});

var gdp_styleLayer = new ol.layer.Vector({
    source: new ol.source.Vector({
        url: 'http://localhost:8585/geoserver/wfs?service=wfs&version=2.0.0&request=GetFeature&typeNames=abschluss_gdd:cotwo&outputFormat=application/json',
        format: new ol.format.GeoJSON(),
    }),
    style: function (feature) {
        return gdp_style;
    },
});


//Map_gdp generation
var map1 = new ol.Map({
    target: 'map_gdp',
    view: view,
    layers: [
        gdplayer,
        gdp_styleLayer,
    ]
});

//cotwo WMS-Layer
var cotwolayer = new ol.layer.Tile({
    // Countries have transparency, so do not fade tiles:
    opacity: 1,
    visible: true,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8585/geoserver/abschluss_gdd/wms?',
        params: { 'LAYERS': 'abschluss_gdd:cotwo'},
        serverType: 'geoserver',
        crossOrigin: null,

    })
});

//cotwo WFS-Layer
var cotwo_style = new ol.style.Style({
    stroke: new ol.style.Stroke({
        color: 'rgba(0, 0, 0)',
        width: 1,
    }),
});

var cotwo_styleLayer = new ol.layer.Vector({
    source: new ol.source.Vector({
        url: 'http://localhost:8585/geoserver/wfs?service=wfs&version=2.0.0&request=GetFeature&typeNames=abschluss_gdd:cotwo&outputFormat=application/json',
        format: new ol.format.GeoJSON(),
    }),
    style: function (feature) {
        return cotwo_style;
    },
});

//Map_cotwo generation
var map2 = new ol.Map({
    target: 'map_cotwo',
    view: view,
    layers: [
    /* new ol.layer.Tile({
         source: new ol.source.OSM()
     }),*/
        cotwolayer,
        cotwo_styleLayer,
    ]
});

//Slider
/*
var dates = ['1980', '1981', '1982', '1983', '1984', '1985', '1986', '1987', '1988', '1989',
    '1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999',
    '2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009',
    '2010', '2011', '2012', '2013', '2014', '2015', '2016']

var sliderRange = document.getElementById("myRange");
    sliderRange.max = sliderRange.length-1;

console.log(sliderRange.value);

      var dateValue = document.getElementById("date_value");
      dateValue.innerHTML = sliderRange.value.slice(0,40);
      /*cotwolayer.getSource().updateParams({'VIEW': sliderRange.value});


      // Update the current slider value (each time you drag the slider handle)
      sliderRange.oninput = function() {
      dateValue.innerHTML = dates[this.value].slice(0,10);
      cotwolayer.getSource().updateParams({'YEAR': dates[this.value]});
      }*/


//Slider ~alt~

var slider = document.getElementById("myRange");
var output = document.getElementById("date_value");
output.innerHTML = slider.value;

slider.oninput = function () {
    output.innerHTML = this.value;
}

function updateslider(sliderVal) {
    gdplayer.getSource().updateParams({ 'viewparams': 'year:' + sliderVal });
    cotwolayer.getSource().updateParams({ 'viewparams': 'year:' + sliderVal });
    document.getElementById('date_value').innerHTML = sliderVal
};

document.getElementById("myRange").addEventListener('input', function () {
    updateslider(this.value);
});


//howerevent
map1.on('pointermove', onMouseMove);

function onMouseMove(browserEvent) {
    var coordinate = browserEvent.coordinate;
    var gdp_feature = gdplayer.getSource().getClosestFeatureToCoordinate(coordinate);
    var cotwo_feature = cotwolayer.getSource().getClosestFeatureToCoordinate(coordinate);

    var land = gdp_feature.getProperties().country;

    var gdp = gdp_feature.getProperties().gdp;
    var cotwo = cotwo_feature.getProperties().co2;

    document.getElementById('land').innerHTML = land;
    document.getElementById('cotwo').innerHTML = cotwo;
    document.getElementById('gdp').innerHTML = gdp;
}

map2.on('pointermove', onMouseMove);

function onMouseMove(browserEvent) {
    var coordinate = browserEvent.coordinate;
    var gdp_feature = gdp_styleLayer.getSource().getClosestFeatureToCoordinate(coordinate);
    var cotwo_feature = cotwo_styleLayer.getSource().getClosestFeatureToCoordinate(coordinate);

    var land = gdp_feature.getProperties().country;

    var gdp = gdp_feature.getProperties().gdp;
    var cotwo = cotwo_feature.getProperties().co2;

    document.getElementById('land').innerHTML = land;
    document.getElementById('cotwo').innerHTML = cotwo;
    document.getElementById('gdp').innerHTML = gdp;
}

//fullscreen
var isFullscreen = false;

function fullscreen_cotwo() {
    var d = {};
    var speed = 300;
    if (!isFullscreen) { // MAXIMIZATION
        d.width = "100%";
        d.height = "100%";
        isFullscreen = true;
        $("alles").slideUp(speed);
    }
    else { // MINIMIZATION            
        d.width = "49%";
        d.height = "500px";
        isFullscreen = false;
        $("alles").slideDown(speed);
    }
    $("#map_cotwo").animate(d, speed);
}
